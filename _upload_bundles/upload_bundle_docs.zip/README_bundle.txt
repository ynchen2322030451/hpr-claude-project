Bundle: upload_bundle_docs.zip
Purpose: paper drafts, project notes, and workflow guidance.
Recommended to upload first when continuing writing/review tasks.
