Bundle: upload_bundle_code_core.zip
Purpose: canonical 0310 code path for training, UQ, Sobol, inverse, OOD, speed, and plotting.
Excludes __pycache__ and legacy archive directories by design.
