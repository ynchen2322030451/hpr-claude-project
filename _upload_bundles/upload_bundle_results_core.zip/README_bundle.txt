Bundle: upload_bundle_results_core.zip
Purpose: canonical fixed artifacts and main paper-ready summaries.
This is the most important results bundle for downstream interpretation.
