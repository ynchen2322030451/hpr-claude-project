Bundle: upload_bundle_data_light.zip
Purpose: essential structured data needed to understand the surrogate dataset.
Does not include the full raw printout archive.
