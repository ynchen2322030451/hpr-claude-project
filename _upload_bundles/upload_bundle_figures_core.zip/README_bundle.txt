Bundle: upload_bundle_figures_core.zip
Purpose: main paper figures only, not all intermediate plotting outputs.
